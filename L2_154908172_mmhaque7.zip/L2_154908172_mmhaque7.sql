-- ***********************
-- Name: Md Mehedi Haque
-- ID: 154908172
-- Date: Sept 13, 2018
-- Purpose: Lab 2 DBS301
-- ***********************

--Q1-displayed employee cardential such as employee ID , last name and salary 
--where the earning is in the range of $9,000 to $11,00. Sorted the output
--by top salaries and then by employee last name.

SELECT  
        employee_id AS EmployeeID,
        last_name As LastName,
        to_char(salary,'$999,999.99') AS Salary
    FROM employees
    WHERE salary BETWEEN 9000 AND 11000
    ORDER BY salary DESC, last_name;

--Q2-Modified Q1 to include Programmers or Sales Representives.
--While keeping sort output at Q1.

SELECT 
        employee_id AS EmployeeID,
        last_name AS LastName,
        to_char(salary,'$999,999.99') AS Salary
    FROM employees
    WHERE
        job_id IN ('IT_PROG','SA_REP') AND
        (salary BETWEEN 9000 AND 11000)
    ORDER BY salary DESC, last_name;
--Q3- Modified the Q2 but the range is is find the highest
--and lowest salary employee. With the same sorting as Q1 
--and Q2.
SELECT 
        employee_id AS EmployeeID,
        last_name AS LastName,
        to_char(salary,'$999,999.99') AS Salary
    FROM employees
    WHERE
        job_id IN ('IT_PROG','SA_REP') AND
        (salary < 9000 OR salary > 11000)
    ORDER BY salary DESC, last_name;

--Q4- Displayed the last name, job_id and salary of employees who
--were hired before 1998 for the company thank you dinner. listed
--recent hires first.
SELECT
        last_name AS LastName,
        job_id AS JobID,
        to_char(salary,'$999,999.99' )AS Salary
    From employees
    WHERE hire_date < TO_DATE('19980101','yyyymmdd')
            
    ORDER BY hire_date DESC;

--Q5- Modified Q4 where it only displays employees earning more
--than $10,000. listed the job title alphabetically and
--by the higest paid employee.
SELECT
        last_name AS LastName,
        job_id AS JobID,
        to_char(salary,'$999,999.99' )AS Salary
    From employees
    WHERE 
        hire_date < TO_DATE('19980101','yyyymmdd') AND
        (salary > 10000)     
    ORDER BY job_id, salary DESC;
    
--Q6- Displayed the job title and Full Name of employees whose fisrt 
-- name contains and 'e' or 'E'.
SELECT 
        job_id AS "Job Title",
        TRIM(first_name)|| ' '||last_name AS "Full name"
    FROM employees
    WHERE REGEXP_LIKE (first_name, '[eE]');
-------------------------------------------------------------------------------
--Q7--created a report that displays the last name, salary and commission 
--percent for all employees that earn a comminsion.
SELECT
        last_name AS "Last Name",
        to_char(salary,'$999,999.99' ) AS Salary,
        commission_pct AS "Commision %"
    FROM employees
    Where
        commission_pct > 0;
        
--Q8--changed Q7 where the salary is descending order.
SELECT
        last_name AS "Last Name",
       to_char(salary,'$999,999.99' ) AS Salary,
        commission_pct AS "Commision %"
    FROM employees
    Where
        commission_pct > 0
    ORDER BY salary DESC;
--Q9--Same as Q8 but sorting with numeric value
SELECT
        last_name AS "Last Name",
        to_char(salary,'$999,999.99' ) AS Salary,
        commission_pct AS "Commision %"
    FROM employees
    Where
        commission_pct > 0
    ORDER BY 2 DESC;
    
    
----------End of File----------------------------------------